Daylight GNU/Linux — Media kit

Founder and developer: Hamdy Abou El Anein
Contact: info@daylightlinux.ch
Primary target: Raspberry Pi OS 64-bit (ARM64).
The AMD64 PC live image is a way to discover and test the desktop.
Published version: 5.0.0-rc.2 (release candidate).
Website: https://daylightlinux.ch
Source: https://github.com/hamdyaea/Daylight-GNU-Linux

Keep attribution. Daylight source and logo: GPL-3.0-only.
Screenshots show the published PC/VM live environment, not Pi performance measurements.
Artwork provenance and third-party rights are detailed in CREDITS.txt.
No font files are distributed. No invented user counts, ratings or speedup claims.
