# Daylight Web Preview

Developer: Hamdy Abou El Anein — info@daylightlinux.ch.
Daylight glue and interface: GPL-3.0-only. Upstream licenses remain separate.

## What users get

https://daylightlinux.ch/live/ opens a real graphical Linux guest without a GitHub account. Start downloads the emulator, firmware, kernel and initramfs; it then boots Alpine x86 and Fluxbox inside WebAssembly. Windows, the taskbar, the desktop menu and xterm are real guest processes. The Desktop, Linux menu and Terminal controls send fixed physical key sequences to Fluxbox.

The guest receives 256 MiB of RAM plus 8 MiB video memory. The browser/emulator needs additional memory. The six runtime payloads total about 42 MB; timing depends on the device and network. Nothing boots or downloads the guest payload before Start. Background tabs pause a running guest and the session is stopped after 20 minutes. Stop/reset/closing discards modifications. No guest network relay, shared host filesystem, account, clipboard bridge or telemetry is configured. Serving the page still exposes ordinary connection metadata to hosting/network providers.

This is an experimental, deliberately pruned Alpine preview, not the complete Debian Daylight release, a Raspberry Pi emulator, or a generally upgradeable Alpine system. The main product remains Raspberry Pi OS/Debian ARM64. The full Debian AMD64 ISO remains available separately.

## Why it does not need a dedicated server

v86 executes the guest on the visitor's device; the production Raspberry Pi only serves static files. Docker is not required at runtime. A future server-side full-ISO service would be a different design, requiring isolated per-user guests, resource/session limits, abuse controls and capacity planning. It must not share an unrestricted Docker socket, production disks, SSH agent or application credentials with visitors.

## Rebuild safely

Build on an unprivileged x86_64 Linux workstation, not on the production Pi. Prerequisites are Python 3, Node.js, bubblewrap, curl, bsdtar, cpio, gzip and Bash, with working user namespaces. The build never installs guest packages into the host. Alpine package signature verification stays enabled.

```sh
python3 web-live/build.py
node web-live/test-boot.mjs
python3 web-live/collect-sources.py
python3 web-live/package.py
```

An existing disposable root requires explicit `--reuse`. Inputs, package versions, firmware and original source hashes are pinned. Distribution mirrors can eventually remove old package versions; preserve published release inputs and corresponding sources. This is not a claim of cross-host byte reproducibility.

`collect-sources.py` retains the exact copyleft-origin sources/patches and aports recipes and the upstream firmware/emulator sources. `package.py` checks those hashes and creates an allowlisted runtime plus a separate corresponding-source ZIP. The large source ZIP is never part of the normal startup download. No host font files, credentials, signing keys, host homes or private logs are published.

## Validate the actual graphical guest

Serve `dist/web-live-publish` on 127.0.0.1:34403. With Playwright and Chromium installed in a project-local environment:

```sh
node web-live/test-browser.cjs
```

The browser check waits for actual graphical readiness, captures the canvas, types through the browser into xterm and verifies the resulting guest file, opens a second terminal, hides/restores real windows, opens the menu, and checks pause/resume/stop. It rejects external-origin requests and pre-consent guest downloads. A serial boot message alone is not sufficient.

Use `DAYLIGHT_DEMO_URL=https://daylightlinux.ch/live/` to repeat it against public HTTPS. `DAYLIGHT_PLAYWRIGHT` and `DAYLIGHT_BROWSER` can point to existing project-local tools. This is not physical Safari/iOS certification; a desktop/laptop browser with keyboard and mouse is recommended.

Publication uses `server/deploy-web-live.py`, requiring successful browser evidence for the exact runtime manifest. The general website deployer skips `/live` so a site rebuild cannot replace a validated runtime. Payload filenames contain content hashes; metadata and the HTML entry point are replaced last. No emulator daemon or public server-side container is launched.

Upstream documentation: https://github.com/copy/v86 and https://copy.sh/v86/ .
